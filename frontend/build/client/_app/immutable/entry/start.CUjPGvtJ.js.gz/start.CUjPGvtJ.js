import{l as o,a as r}from"../chunks/Da7Di7hP.js";export{o as load_css,r as start};
